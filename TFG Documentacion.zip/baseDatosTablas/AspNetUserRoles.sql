create table "AspNetUserRoles"
(
    "UserId" text not null
        constraint "FK_AspNetUserRoles_AspNetUsers_UserId"
            references "AspNetUsers"
            on delete cascade,
    "RoleId" text not null
        constraint "FK_AspNetUserRoles_AspNetRoles_RoleId"
            references "AspNetRoles"
            on delete cascade,
    constraint "PK_AspNetUserRoles"
        primary key ("UserId", "RoleId")
);

alter table "AspNetUserRoles"
    owner to admin;

create index "IX_AspNetUserRoles_RoleId"
    on "AspNetUserRoles" ("RoleId");

INSERT INTO public."AspNetUserRoles" ("UserId", "RoleId") VALUES ('f8401b76-ced1-45e5-bc77-16bb25a0387c', '9c434ea7-d51b-477f-ba7d-aca05f3f8cb4');
INSERT INTO public."AspNetUserRoles" ("UserId", "RoleId") VALUES ('54dd6f7d-a6c5-4749-9585-4b8e295f3e9e', '1c5d903c-9ac1-4fe9-8744-5b2ab1a1cb14');
INSERT INTO public."AspNetUserRoles" ("UserId", "RoleId") VALUES ('7489be61-c68e-4bb2-a739-389ea9bd6964', '1c5d903c-9ac1-4fe9-8744-5b2ab1a1cb14');
INSERT INTO public."AspNetUserRoles" ("UserId", "RoleId") VALUES ('976dd103-b0f4-4505-9aa3-539b38e5112a', '1c5d903c-9ac1-4fe9-8744-5b2ab1a1cb14');
INSERT INTO public."AspNetUserRoles" ("UserId", "RoleId") VALUES ('f5176757-966a-4193-9273-3063e9371959', '1c5d903c-9ac1-4fe9-8744-5b2ab1a1cb14');
