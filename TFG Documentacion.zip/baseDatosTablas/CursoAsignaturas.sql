create table "CursoAsignaturas"
(
    "AsignaturasId" integer not null
        constraint "FK_CursoAsignaturas_Asignaturas_AsignaturasId"
            references "Asignaturas"
            on delete cascade,
    "CursosId"      integer not null
        constraint "FK_CursoAsignaturas_Cursos_CursosId"
            references "Cursos"
            on delete cascade,
    constraint "PK_CursoAsignaturas"
        primary key ("AsignaturasId", "CursosId")
);

alter table "CursoAsignaturas"
    owner to admin;

create index "IX_CursoAsignaturas_CursosId"
    on "CursoAsignaturas" ("CursosId");

INSERT INTO public."CursoAsignaturas" ("AsignaturasId", "CursosId") VALUES (1, 1);
INSERT INTO public."CursoAsignaturas" ("AsignaturasId", "CursosId") VALUES (1, 2);
INSERT INTO public."CursoAsignaturas" ("AsignaturasId", "CursosId") VALUES (2, 1);
INSERT INTO public."CursoAsignaturas" ("AsignaturasId", "CursosId") VALUES (2, 2);
