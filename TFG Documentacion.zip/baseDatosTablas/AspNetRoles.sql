create table "AspNetRoles"
(
    "Id"               text not null
        constraint "PK_AspNetRoles"
            primary key,
    "Name"             varchar(256),
    "NormalizedName"   varchar(256),
    "ConcurrencyStamp" text
);

alter table "AspNetRoles"
    owner to admin;

create unique index "RoleNameIndex"
    on "AspNetRoles" ("NormalizedName");

INSERT INTO public."AspNetRoles" ("Id", "Name", "NormalizedName", "ConcurrencyStamp") VALUES ('9c434ea7-d51b-477f-ba7d-aca05f3f8cb4', 'Director', 'DIRECTOR', null);
INSERT INTO public."AspNetRoles" ("Id", "Name", "NormalizedName", "ConcurrencyStamp") VALUES ('1c5d903c-9ac1-4fe9-8744-5b2ab1a1cb14', 'Profesor', 'PROFESOR', null);
