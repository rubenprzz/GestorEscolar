create table "AlumnoPadres"
(
    "AlumnosId" integer not null
        constraint "FK_AlumnoPadres_Alumnos_AlumnosId"
            references "Alumnos"
            on delete cascade,
    "PadresId"  integer not null
        constraint "FK_AlumnoPadres_Padres_PadresId"
            references "Padres"
            on delete cascade,
    constraint "PK_AlumnoPadres"
        primary key ("AlumnosId", "PadresId")
);

alter table "AlumnoPadres"
    owner to admin;

create index "IX_AlumnoPadres_PadresId"
    on "AlumnoPadres" ("PadresId");

INSERT INTO public."AlumnoPadres" ("AlumnosId", "PadresId") VALUES (2, 1);
