create table "AspNetUsers"
(
    "Id"                   text    not null
        constraint "PK_AspNetUsers"
            primary key,
    dni                    text    not null,
    "UserName"             varchar(256),
    "NormalizedUserName"   varchar(256),
    "Email"                varchar(256),
    "NormalizedEmail"      varchar(256),
    "EmailConfirmed"       boolean not null,
    "PasswordHash"         text,
    "SecurityStamp"        text,
    "ConcurrencyStamp"     text,
    "PhoneNumber"          text,
    "PhoneNumberConfirmed" boolean not null,
    "TwoFactorEnabled"     boolean not null,
    "LockoutEnd"           timestamp with time zone,
    "LockoutEnabled"       boolean not null,
    "AccessFailedCount"    integer not null
);

alter table "AspNetUsers"
    owner to admin;

create index "EmailIndex"
    on "AspNetUsers" ("NormalizedEmail");

create unique index "UserNameIndex"
    on "AspNetUsers" ("NormalizedUserName");

INSERT INTO public."AspNetUsers" ("Id", dni, "UserName", "NormalizedUserName", "Email", "NormalizedEmail", "EmailConfirmed", "PasswordHash", "SecurityStamp", "ConcurrencyStamp", "PhoneNumber", "PhoneNumberConfirmed", "TwoFactorEnabled", "LockoutEnd", "LockoutEnabled", "AccessFailedCount") VALUES ('f8401b76-ced1-45e5-bc77-16bb25a0387c', '12345678A', 'director@admin.com', 'DIRECTOR@ADMIN.COM', 'director@admin.com', 'DIRECTOR@ADMIN.COM', false, 'AQAAAAIAAYagAAAAEEhevEhN2v7zG/tGIBf9xNa+franq9+ZTiXa8Do0aDbsmnGMV/gCynqz2mtK7Ltt/g==', 'GZKDBOGUVE5SMTZAPZCYIGQVW4XLDM6K', '03bb17ac-3fc6-4b79-8d52-5795e69e3261', null, false, false, null, true, 0);
INSERT INTO public."AspNetUsers" ("Id", dni, "UserName", "NormalizedUserName", "Email", "NormalizedEmail", "EmailConfirmed", "PasswordHash", "SecurityStamp", "ConcurrencyStamp", "PhoneNumber", "PhoneNumberConfirmed", "TwoFactorEnabled", "LockoutEnd", "LockoutEnabled", "AccessFailedCount") VALUES ('54dd6f7d-a6c5-4749-9585-4b8e295f3e9e', '12345678A', 'admindd@instituto.edu', 'ADMINDD@INSTITUTO.EDU', 'admindd@instituto.edu', 'ADMINDD@INSTITUTO.EDU', false, 'AQAAAAIAAYagAAAAEGW+wSNCW/UN6SeDGnCt2zTLeQYDwqhX8KeylUhV3ET9Yry5RGWvIs1VfRyDXIjeTQ==', 'OCZ5WOHW5WYOTTJNRV255XHNQ6Q4OIYZ', '1d2e63ea-2c15-46ca-b057-557d7c2dd39d', null, false, false, null, true, 0);
INSERT INTO public."AspNetUsers" ("Id", dni, "UserName", "NormalizedUserName", "Email", "NormalizedEmail", "EmailConfirmed", "PasswordHash", "SecurityStamp", "ConcurrencyStamp", "PhoneNumber", "PhoneNumberConfirmed", "TwoFactorEnabled", "LockoutEnd", "LockoutEnabled", "AccessFailedCount") VALUES ('7489be61-c68e-4bb2-a739-389ea9bd6964', '49153695G', 'r@gmail.com', 'R@GMAIL.COM', 'r@gmail.com', 'R@GMAIL.COM', false, 'AQAAAAIAAYagAAAAEN5zWTdwMptHvLpc0Xrix35FFJVSlpLdiLfTZWYeBFORvhV+ECFsa9xcdAGH0Pg56g==', 'DVFMGU4QNKFDNKXADQLDRL3GDA5O7V6H', 'f428af55-e65f-4b24-9bd9-8e54ac087819', null, false, false, null, true, 0);
INSERT INTO public."AspNetUsers" ("Id", dni, "UserName", "NormalizedUserName", "Email", "NormalizedEmail", "EmailConfirmed", "PasswordHash", "SecurityStamp", "ConcurrencyStamp", "PhoneNumber", "PhoneNumberConfirmed", "TwoFactorEnabled", "LockoutEnd", "LockoutEnabled", "AccessFailedCount") VALUES ('976dd103-b0f4-4505-9aa3-539b38e5112a', '49153695G', 'rubenfernandezp03@gmail.com', 'RUBENFERNANDEZP03@GMAIL.COM', 'rubenfernandezp03@gmail.com', 'RUBENFERNANDEZP03@GMAIL.COM', false, 'AQAAAAIAAYagAAAAEMbhtmZAhpIfyJzb1DcTu5HK2NXlS59kssN3uUwyuXdGN5WU3lC5UoQpTyzzU9+0Hg==', 'RQH3FHMTB43GPMEEPEYFWJ23S7WNZLS3', '265881fb-5533-429d-b4bd-7770dfcb6915', null, false, false, null, true, 0);
INSERT INTO public."AspNetUsers" ("Id", dni, "UserName", "NormalizedUserName", "Email", "NormalizedEmail", "EmailConfirmed", "PasswordHash", "SecurityStamp", "ConcurrencyStamp", "PhoneNumber", "PhoneNumberConfirmed", "TwoFactorEnabled", "LockoutEnd", "LockoutEnabled", "AccessFailedCount") VALUES ('f5176757-966a-4193-9273-3063e9371959', '12345678A', 'prueba@instituto.edu', 'PRUEBA@INSTITUTO.EDU', 'prueba@instituto.edu', 'PRUEBA@INSTITUTO.EDU', false, 'AQAAAAIAAYagAAAAEBTlltu6x9x12r1xribGs/ggiskBSAVkZhvNWTiX7rqma4sGzRc/gkTTMPiARUVHCA==', 'MQITI5UMZCUEWTIEDSIHMIPJJUAUB3DJ', '17235048-ab44-499f-a9b2-7ac8461b9e02', null, false, false, null, true, 0);
